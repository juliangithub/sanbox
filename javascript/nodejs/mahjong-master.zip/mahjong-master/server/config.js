/*global module */

module.exports = {
    SOCKET_IO_NAMESPACE: 'game',
    CRYPTO_AES_SECRET: 'fhqwhgads',
    EXPRESS_SESSION_SECRET: 'fhqwhgads',
    EXPRESS_COOKIE_SECRET: 'fhqwhgads',
    GITHUBHOOK_SECRET: 'fhqwhgads'
};
